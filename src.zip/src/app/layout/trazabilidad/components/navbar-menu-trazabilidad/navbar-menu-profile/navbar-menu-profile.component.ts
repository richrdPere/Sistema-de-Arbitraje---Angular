import { Component, OnInit } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';

// IziToast
import iziToast from 'izitoast';

// Interface
import { MenuOptions } from 'src/app/interfaces/components/MenuOptions';

// Servicio
import { AuthService } from 'src/app/services/auth.service';
import { PerfilService } from 'src/app/services/perfil.service';


@Component({
  selector: 'navbar-menu-profile',
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './navbar-menu-profile.component.html',
})
export class NavbarMenuProfileComponent implements OnInit {

  // variables
  public name: string = '';
  public email: string = '';
  public avatar: string = '';


  constructor(
    private _authService: AuthService,
    private perfilService: PerfilService,
    private _router: Router
  ) {


  }
  ngOnInit(): void {
    this._authService.currentUser$.subscribe(usuario => {

      if (!usuario) return;

      this.name = usuario.nombre;
      this.email = usuario.correo;

      this.avatar = usuario.foto_perfil
        ? `${this.perfilService.envs.url_image}${usuario.foto_perfil}?t=${Date.now()}`
        : 'assets/img/default-avatar.png';

    });
  }

  menuOptions: MenuOptions[] = [
    {
      icon: 'assets/icons/navbar/perfil.svg',
      label: 'Perfil',
      route: '/app/perfil',
    },
    {
      icon: 'assets/icons/navbar/settings.svg',
      label: 'Configuración',
      route: '/app/configuracion',
    },
    {
      icon: 'assets/icons/navbar/sign_out.svg',
      label: 'Cerrar Sesión',
      route: '/trazabilidad',  //   route: '/login',
    },

  ];

  logout() {
    this._authService.logout();

    iziToast.info({
      title: 'Sesión cerrada',
      message: 'Has cerrado sesión correctamente',
      position: 'bottomRight',
    });
    this._router.navigate(['/trazabilidad']);   //  this._router.navigate(['/login']);
  }

}
